🚨 저작권 및 사용 제한 저작권자: © 2025 [HealingK]

All Rights Reserved.

이 데이터의 복사, 수정, 재배포, 상업적 이용을 금지합니다.

본 데이터는 깃허브 저장소에 공개되어 있어도 자유롭게 사용할 수 있는 것이 아닙니다.

❌ 허용되지 않는 사항 개인 및 상업적 사용 불가 (Personal & Commercial Use Prohibited)

수정 및 2차 창작 금지 (No Modification or Derivative Works)

데이터를 블로그, SNS, 웹사이트 등에 공유 금지 (No Public Sharing)

재판매 또는 유료 서비스에서 사용 금지 (No Resale or Paid Services)

📌 법적 경고 위의 사항을 위반할 경우, 저작권법에 따라 법적 책임을 물을 수 있습니다.

무단 사용이 적발될 경우, 즉시 삭제 요청 및 법적 조치를 진행할 수 있습니다.

📬 문의 (Contact) 이 데이터 사용에 대한 허가가 필요한 경우, 아래 연락처로 문의해 주세요. 📧 Email: eternityland34@gmail.com

🔒 본 README 파일의 내용을 삭제하거나 변경해도 저작권 보호는 계속 유지됩니다.
